import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
import emailjs from 'emailjs-com';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-recuperar-password',
  templateUrl: './recuperar-password.page.html',
  styleUrls: ['./recuperar-password.page.scss'],
})
export class RecuperarPasswordPage {
  email: string = '';
  mensaje: string = '';

  private apiUrl = 'https://galkotfinal.onrender.com/usuarios';

  constructor(
    private http: HttpClient,
    private toast: ToastController,
    private router: Router
  ) {
    emailjs.init('zQPBgGHiSSjbrf4QS'); 
  }

  enviarCorreo() {
    if (!this.email) {
      this.mensaje = 'Por favor ingresa un correo electrónico.';
      this.showToast(this.mensaje);
      return;
    }

    this.http.get<any[]>(`${this.apiUrl}?email=${this.email}`).subscribe((usuarios) => {
      if (usuarios.length > 0) {
        const usuario = usuarios[0];
        const resetToken = uuidv4();
        const resetTokenExpiration = new Date();
        resetTokenExpiration.setHours(resetTokenExpiration.getHours() + 1);
        this.http.patch(`${this.apiUrl}/${usuario.id}`, { 
          resetToken, 
          resetTokenExpiration: resetTokenExpiration.toISOString()
        }).subscribe(() => {
          console.log('Token actualizado para el usuario:', resetToken);
          this.enviarCorreoConToken(resetToken, usuario.email);
        });
      } else {
        this.mensaje = 'El correo electrónico no está registrado.';
        this.showToast(this.mensaje);
      }
    });
  }

  enviarCorreoConToken(token: string, email: string) {
    const link = `http://localhost:8100/restablecer-password?resetToken=${token}`;
    const templateParams = {
      to_email: email,
      resetCode: token,
      link: link, 
    };
  
    emailjs.send('service_jkldopf', 'template_z7tkkre', templateParams)
      .then((response) => {
        console.log('Correo enviado:', response);
        this.mensaje = 'Se ha enviado un enlace de restablecimiento a tu correo.';
        this.showToast(this.mensaje);
      })
      .catch((error) => {
        console.log('Error al enviar correo:', error);
        this.mensaje = 'Error al enviar el correo, intenta nuevamente.';
        this.showToast(this.mensaje);
      });
  }
  

  async showToast(msg: string) {
    const toast = await this.toast.create({
      message: msg,
      duration: 3000,
      position: 'bottom',
    });
    toast.present();
  }

  volver() {
    this.router.navigateByUrl("/ingreso");
  }
}
