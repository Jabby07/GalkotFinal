import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';
import { UserNuevo } from 'src/interfaces/user';

@Component({
    selector: 'app-registro',
    templateUrl: './registro.page.html',
    styleUrls: ['./registro.page.scss'],
    standalone: false
})
export class RegistroPage {

  registroForm: FormGroup;

  nuevoUsuario: UserNuevo={
    username:"",
    email:"",
    rut:"",
    password:"",
    isactive:false
  }
  userdata: any;

  constructor(private authservice:AuthService,
    private alertcontroller:AlertController,
    private router:Router,
    private fBuilder:FormBuilder) {
      this.registroForm = this.fBuilder.group({
        'username' : new FormControl ("", [Validators.required, Validators.minLength(6)]),
        'email' : new FormControl ("", [Validators.required, Validators.email]),
        'password' : new FormControl("", [Validators.required, Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/)]),
        'rut': new FormControl("", [Validators.required,Validators.minLength(12)])
      })
     }

     crearUsuario(){
      if(this.registroForm.valid){
        this.authservice.GetUserByUsername(this.registroForm.value.username).subscribe(resp=>{
          this.userdata = resp;
          if(this.userdata.length>0){
            this.registroForm.reset();
            this.errorDuplicidad();
          }
          else{
            this.nuevoUsuario.username = this.registroForm.value.username;
            this.nuevoUsuario.password = this.registroForm.value.password;
            this.nuevoUsuario.email = this.registroForm.value.email;
            this.nuevoUsuario.rut = this.registroForm.value.rut;
            this.nuevoUsuario.isactive=true;
            this.authservice.PostUsuario(this.nuevoUsuario).subscribe();
            this.registroForm.reset();
            this.mostrarMensaje();
            this.router.navigateByUrl("/login");
          }
        })
      }
    }

    formatoRUT(event: any) {
      let value = event.target.value;
      value = value.replace(/[.-]/g, '');
      if (value.length > 1) {
        value = value.replace(/^(\d{1,2})(\d{3})(\d{3})([\dkK])$/, '$1.$2.$3-$4');
      }
      event.target.value = value;
      this.registroForm.controls['rut'].setValue(value);
    }
    
    async mostrarMensaje(){
      const alerta = await this.alertcontroller.create({
        header: 'Usuario Creado',
        message: 'Gracias Por Registrarte ' + this.nuevoUsuario.username,
        buttons: ['OK']
      });
      alerta.present();
    }
    async errorDuplicidad(){
      const alerta = await this.alertcontroller.create({
        header: 'Error..',
        message: 'Este usuario:' + this.nuevoUsuario.username + 'ya existe ',
        buttons: ['OK']
      });
      alerta.present();
    }

    volver(){
      this.router.navigateByUrl("/login");
    }
}
