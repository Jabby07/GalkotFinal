import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DetallesPageRoutingModule } from './detalles-routing.module';
import { QRCodeModule } from 'angularx-qrcode';
import { DetallesPage } from './detalles.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DetallesPageRoutingModule,
    QRCodeModule
  ],
  declarations: [DetallesPage]
})
export class DetallesPageModule {}
