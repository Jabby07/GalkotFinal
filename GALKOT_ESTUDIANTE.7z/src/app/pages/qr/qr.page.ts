import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-qr',
    templateUrl: './qr.page.html',
    styleUrls: ['./qr.page.scss'],
    standalone: false
})
export class QrPage implements OnInit {

  constructor(
    public router:Router,
  ) { }

  ngOnInit() {
  }

  async volver(){
    const alert = await this.router.navigate(['/tabs/tab1'])
  }
}
