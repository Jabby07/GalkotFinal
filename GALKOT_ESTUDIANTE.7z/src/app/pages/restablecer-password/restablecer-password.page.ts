import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-restablecer-password',
  templateUrl: './restablecer-password.page.html',
  styleUrls: ['./restablecer-password.page.scss'],
})
export class RestablecerPasswordPage implements OnInit {
  resetToken: string = '';
  nuevaPassword: string = '';
  mensaje: string = '';

  private apiUrl = 'https://galkotfinal.onrender.com/usuarios';

  constructor(
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private toast: ToastController,
    private router: Router
  ) {}

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(params => {
      this.resetToken = params['resetToken'];
      console.log('Reset Token:', this.resetToken);
    });
  }

  restablecerPassword() {
    if (!this.resetToken || !this.nuevaPassword) {
      this.mensaje = 'Por favor, completa todos los campos.';
      this.showToast(this.mensaje);
      return;
    }

    if (this.nuevaPassword.length < 8) {
      this.mensaje = 'La contraseña debe tener al menos 8 caracteres.';
      this.showToast(this.mensaje);
      return;
    }
    
    this.http.get<any[]>(`${this.apiUrl}?resetToken=${this.resetToken}`).subscribe((usuarios) => {
      if (usuarios.length > 0) {
        const usuario = usuarios[0];
        const now = new Date();
        const expirationDate = new Date(usuario.resetTokenExpiration);
        if (now > expirationDate) {
          this.mensaje = 'El token de recuperación ha expirado.';
          this.showToast(this.mensaje);
          return;
        }

        console.log('Usuario encontrado:', usuario); 
        this.http.patch(`${this.apiUrl}/${usuario.id}`, { password: this.nuevaPassword, resetToken: '', resetTokenExpiration: '' })
          .subscribe(() => {
            this.mensaje = 'Tu contraseña ha sido restablecida correctamente.';
            this.showToast(this.mensaje);
            this.router.navigateByUrl('/login');
          });
      } else {
        this.mensaje = 'El token de recuperación es inválido o ha expirado.';
        this.showToast(this.mensaje);
      }
    });
  }

  async showToast(msg: string) {
    const toast = await this.toast.create({
      message: msg,
      duration: 3000,
      position: 'bottom',
    });
    toast.present();
  }

  volver() {
    this.router.navigateByUrl("/ingreso");
  }
}
