import { Injectable } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ToastController } from '@ionic/angular';
import { UrlTree } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AutorizadoGuard {

  constructor(
    private authService: AuthService,
    private toast: ToastController,
    private router: Router
  ) {}

  canActivate(): boolean | UrlTree {
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/tabs/tab1']);
      return false;
    } else {
      return true;
    }
  }
  
  async showToast(msg: string) {
    const toast = await this.toast.create({
      message: msg,
      duration: 3000
    });
    toast.present();
  }
}