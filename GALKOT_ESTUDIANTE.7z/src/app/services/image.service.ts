import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ImageService {
  private imageSrc: string | ArrayBuffer | null = null;

  constructor() {}

  getImageSrc(): string | ArrayBuffer | null {
    return this.imageSrc;
  }

  setImageSrc(image: string | ArrayBuffer | null): void {
    this.imageSrc = image;
  }
}