import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostulacionesService {

  private apiUrl = 'https://galkotfinal.onrender.com';

  constructor(private http: HttpClient) { }

  postularTrabajo(postulacion: any): Observable<any> {
    return this.http.post('http://localhost:3000/postulaciones', postulacion);
  }
  getPostulaciones(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/postulaciones`); 
  }
  getPublicacionById(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/publicaciones/${id}`);
  }
  getPostulacionById(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/postulaciones/${id}`);
  }
  getPostulacion(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/postulaciones/${id}`);
  }
  eliminarPostulacion(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/postulaciones/${id}`);
  }
}