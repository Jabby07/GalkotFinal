import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { ImageService } from '../services/image.service';

@Component({
    selector: 'app-tab4',
    templateUrl: 'tab4.page.html',
    styleUrls: ['tab4.page.scss'],
    
})
export class Tab4Page implements OnInit {

  imageSrc: string | ArrayBuffer | null = null;

  user: any;

  constructor(private authService: AuthService,
              private router:Router,
              private imageService: ImageService
  ) {this.imageSrc = localStorage.getItem('imageSrc');

  }

  ngOnInit() {
    const username = sessionStorage.getItem('username');
    if (username) {
      this.authService.GetUserByUsername(username).subscribe(user => {
        if (Array.isArray(user) && user.length > 0) {
          this.user = user[0];
        } else {
          this.user = user;
        }
      });
    }
  }

  editarPerfil() {
    if (this.user && this.user.id) {
      this.router.navigate(['/modificar', this.user.id]);
    } else {
      console.error('No se encontró el ID del usuario');
    }
  }


  onLogout() {
    this.authService.logout();
  }
}