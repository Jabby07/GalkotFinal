export interface Users{
    id:string;
    username:string;
    rut:string;
    email:string;
    password:string;
    isactive:boolean;
}
export interface UserNuevo{
    username:string;
    email:string;
    rut:string;
    password:string;
    isactive:boolean;
}