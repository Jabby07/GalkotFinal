export const environment = {
  production: true,
  apiUrl:'https://galkotfinal.onrender.com'
};
