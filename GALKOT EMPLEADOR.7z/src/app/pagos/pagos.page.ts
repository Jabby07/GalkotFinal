import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import { ApipublicacionesService } from '../services/apipublicaciones.service';
import { PostulacionesService } from '../services/postulaciones.service';

@Component({
  selector: 'app-pagos',
  templateUrl: './pagos.page.html',
  styleUrls: ['./pagos.page.scss'],
})
export class PagosPage implements OnInit {
  publicaciones: any[] = [];
  isAllPaid: boolean = false;
  postulaciones: any[] = [];
  constructor(
    private alertcontroller: AlertController,
    private router: Router,
    private apiPubli: ApipublicacionesService,
    private postulacionesService: PostulacionesService
  ) {}

  ngOnInit() {
    this.cargarPublicaciones(); 
    this.cargarPostulaciones(); // Asegúrate de llamar a este método
  }

  cargarPublicaciones() {
    this.apiPubli.getPublicaciones().subscribe(data => {
      this.publicaciones = data;
    }, error => {
      console.error('Error al obtener las publicaciones:', error);
    });
  }

  cargarPostulaciones() {
    this.postulacionesService.getPostulaciones().subscribe(data => {
      this.postulaciones = data;
    }, error => {
      console.error('Error al obtener las postulaciones:', error);
    });
  }

  togglePago(publicacion: any) {
    publicacion.pagado = !publicacion.pagado;
    this.checkAllPaid();
  }

  checkAllPaid() {
    this.isAllPaid = this.publicaciones.every((pub) => pub.pagado);
  }
}



