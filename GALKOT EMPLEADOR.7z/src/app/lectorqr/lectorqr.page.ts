import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
const { BarcodeScanner } = Plugins;
import { Plugins } from '@capacitor/core';

@Component({
  selector: 'app-lectorqr',
  templateUrl: './lectorqr.page.html',
  styleUrls: ['./lectorqr.page.scss'],
})
export class LectorqrPage implements OnInit {
  scannedCode: string = ''; 

  constructor() {}

  ngOnInit() {
    this.startScan();
  }

  async startScan() {
    const allowed = await BarcodeScanner['checkPermission']({ force: true });

    if (allowed.granted) {
      BarcodeScanner['hideBackground'](); 
      const result = await BarcodeScanner['startScan']();

      if (result.hasContent) {
        this.scannedCode = result.content; 
      }
    } else {
      console.error('Permission denied');
    }
  }

  volveraCargar() {
    window.location.reload(); 
  }
}

