import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { ImageService } from 'src/app/services/image.service';

@Component({
  selector: 'app-editar-perfil',
  templateUrl: './editar-perfil.page.html',
  styleUrls: ['./editar-perfil.page.scss'],
})
export class EditarPerfilPage implements OnInit{

  imageSrc: string | ArrayBuffer | null = null;
  perfilForm: FormGroup;
  UsuarioActual: any;

  constructor(private authService: AuthService,
              private imageService: ImageService,
              private route: ActivatedRoute,
              private router: Router,
              private alertcontroller: AlertController,
              private formBuilder: FormBuilder) {
                        this.perfilForm = this.formBuilder.group({
                        username: ['', [Validators.required, Validators.minLength(6)]],
                        email: ['', [Validators.required, Validators.email]],
                        rut: [''],
                        imagen: [''] 
                     });
                     this.imageSrc = localStorage.getItem('imageSrc');
 }

 ngOnInit() {
  const userId = this.route.snapshot.paramMap.get('id');
  if (userId) {
    this.authService.getPerfil(userId).subscribe(user => {
      this.UsuarioActual = user;
      this.perfilForm.patchValue({
        username: this.UsuarioActual.username,
        email: this.UsuarioActual.email,
        rut: this.UsuarioActual.rut,
        imagen: this.UsuarioActual.imagen
      });
    });
  }
}

async guardarCambios() {
  if (this.perfilForm.valid) {
    const updatedUser = {
      ...this.UsuarioActual,
      ...this.perfilForm.value
    };
    this.authService.updatePerfil(updatedUser.id, updatedUser).subscribe(async () => {
      const alert = await this.alertcontroller.create({
        header: 'Actualización exitosa',
        message: 'Ahora debe iniciar sesión de nuevo.',
        buttons: [{
          text: 'OK',
          handler: () => {
            this.authService.logout(); // Redirigir a la página de inicio de sesión
          }
        }]
      });

      await alert.present();
    });
  }
}

onImageSelected(event: Event): void {
  const input = event.target as HTMLInputElement;
  if (input && input.files && input.files[0]) {
    const file = input.files[0];

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result;
        this.imageService.setImageSrc(this.imageSrc); 
        localStorage.setItem('imageSrc', this.imageSrc as string);
      };
      reader.readAsDataURL(file);  
    } else {
      console.log('El archivo no es una imagen');
    }
  }
}

  volver(){
    this.router.navigateByUrl("/perfil");
  }
}
