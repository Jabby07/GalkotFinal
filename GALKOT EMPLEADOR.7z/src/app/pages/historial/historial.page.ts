import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostulacionesService } from 'src/app/services/postulaciones.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-historial',
  templateUrl: './historial.page.html',
  styleUrls: ['./historial.page.scss'],
})
export class HistorialPage implements OnInit {
  postulacion: any;
  postulaciones: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private postulacionesService: PostulacionesService,
    private router: Router
  ) {}

  ngOnInit() {
    this.cargarHistorial();
  }
  
  cargarHistorial() {
    this.postulacionesService.getPostulaciones().subscribe(data => {
    this.postulaciones = data;
    });
  }

volver() {
  this.router.navigate(['/pagos']);
}

}