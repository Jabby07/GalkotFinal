import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { LoginPage } from '../login/login.page';
import { RegistroPage } from '../registro/registro.page';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage  {

  constructor(private modalcontroller: ModalController,private router: Router) { }

  login() {
    this.router.navigateByUrl("/login");
  }


  registrar() {
    this.router.navigateByUrl("/registro");
  }







}
