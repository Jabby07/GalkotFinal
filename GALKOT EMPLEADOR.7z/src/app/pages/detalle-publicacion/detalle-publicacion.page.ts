import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApipublicacionesService } from 'src/app/services/apipublicaciones.service';
import { AlertController, ToastController } from '@ionic/angular';
import { PostulacionesService } from 'src/app/services/postulaciones.service';

@Component({
  selector: 'app-detalle-publicacion',
  templateUrl: './detalle-publicacion.page.html',
  styleUrls: ['./detalle-publicacion.page.scss'],
})
export class DetallePublicacionPage implements OnInit {
  publicacion: any;
  qrdata: any;
  editMode: boolean = false;


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiPubli: ApipublicacionesService,
    private toast: ToastController,
    private alertController: AlertController ,
    private postulacionesService: PostulacionesService
  ) {
    this.qrdata = '';
  }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.apiPubli.getPublicacionById(id).subscribe(
        (data) => {
          this.publicacion = data;
        },
        (error) => {
          console.error('Error al obtener la publicación:', error);
          if (error.status === 404) {
            alert('Publicación no encontrada');
            this.router.navigate(['/index']);
          }
        }
      );
    } else {
      console.error('ID de publicación no proporcionado');
    }
  }

 

  async generarCodigoQR() {
    this.qrdata = this.publicacion.id + this.publicacion.nombrePublicacion + this.publicacion.codigo + this.publicacion.fecha +
      this.publicacion.hora + this.publicacion.monto + this.publicacion.descripcion;
    console.log(this.qrdata);
  }

  async eliminarPublicacion() {
    const alert = await this.alertController.create({
      header: 'Confirmar Eliminación',
      message: '¿Estás seguro de que deseas eliminar esta publicación?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Eliminación cancelada');
          }
        },
        {
          text: 'Eliminar',
          handler: () => {
            if (this.publicacion && this.publicacion.id) {
              this.apiPubli.eliminarPublicacion(this.publicacion.id).subscribe(
                () => {
                  this.showToast('Publicación eliminada exitosamente');
                  this.router.navigateByUrl('/index').then(() => {
                    location.reload(); // Actualiza la página una vez redirigido
                  });
                },
                (error) => {
                  console.error('Error al eliminar la publicación:', error);
                  this.showToast('Error al eliminar la publicación');
                }
              );
            }
          }
        }
      ]
    });
  
    await alert.present();
  }
  

  habilitarEdicion() {
    this.editMode = true;
  }

  guardarPublicacion() {
    if (this.publicacion && this.publicacion.id) {
      this.apiPubli.updatePublicacion(this.publicacion.id, this.publicacion).subscribe(
        () => {
          this.editMode = false;
          this.showToast('Publicación actualizada exitosamente');
        },
        (error) => {
          console.error('Error al actualizar la publicación:', error);
          this.showToast('Error al actualizar la publicación');
          
        }
        
      );
      
    }
  }

  async showToast(msg: string) {
    const toast = await this.toast.create({
      message: msg,
      duration: 3000
    });
    toast.present();
    location.reload();
  }
  
  volver(){
    this.router.navigateByUrl("/index");
    
  }

  
}
