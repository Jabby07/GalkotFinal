import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApipublicacionesService } from 'src/app/services/apipublicaciones.service';

@Component({
  selector: 'app-publicar',
  templateUrl: './publicar.page.html',
  styleUrls: ['./publicar.page.scss'],
})
export class PublicarPage implements OnInit {
  publicarForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private publicacionService: ApipublicacionesService,
    private router: Router
  ) {
    this.publicarForm = this.formBuilder.group({
      nombrePublicacion: ['', [Validators.required]],
      codigo: [{ value: '', disabled: true }, [Validators.required]],
      fecha: ['', [Validators.required]],
      hora: ['', [Validators.required]],
      monto: ['', [Validators.required, Validators.min(0)]],
      descripcion: ['', [Validators.required]]
    });
  }

  ngOnInit() {
    this.publicarForm.patchValue({
      codigo: this.generateCodigo() 
    });
  }

  onSubmit() {
    if (this.publicarForm.valid) {
      const now = new Date();
      const nuevaPublicacion = {
        ...this.publicarForm.getRawValue(),
        fechaCreacion: now.toLocaleString()
      };
  
      this.publicacionService.createPublicacion(nuevaPublicacion).subscribe(() => {
        window.location.reload(); 
      });
    }
  }


  generateCodigo(): string {
    const prefix = 'TUKI';
    const randomNumbers = Math.floor(1000000 + Math.random() * 9000000).toString(); 
    return `${prefix}${randomNumbers}`;
  }
}


