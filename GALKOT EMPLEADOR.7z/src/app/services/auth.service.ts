import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Users, UserNuevo } from 'src/interfaces/users';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiuserUrl = 'https://galkotfinal.onrender.com/usuarios';

  constructor(private httpclient:HttpClient,
    private router:Router) { }

  GetAllUsers():Observable<Users[]>{
    return this.httpclient.get<Users[]>(`${environment.apiUrl}/usuarios`);
  }
  GetUserByUsername(usuario:any):Observable<Users>{
    return this.httpclient.get<Users>(`${environment.apiUrl}/usuarios/?username=${usuario}`);
  }
  isLoggedIn(){
    return sessionStorage.getItem('username')!=null;
  }
  PostUsuario(nuevoUsuario: UserNuevo): Observable<UserNuevo> {
    return this.httpclient.post<UserNuevo>(`${environment.apiUrl}/usuarios`, nuevoUsuario);
  }
  updateUser(user: Users): Observable<Users> {
    return this.httpclient.put<Users>(`${environment.apiUrl}/usuarios/${user.id}`, user);
  }
  ActualizarUsuario(user: Users): Observable<Users> {
    return this.httpclient.put<Users>(`${environment.apiUrl}/usuarios/${user.id}`, user);
  }

  GetUserById(id: string): Observable<Users> {
    return this.httpclient.get<Users>(`${environment.apiUrl}/usuarios/${id}`);
  }
  
  getPerfil(userId: string): Observable<any> {
    return this.httpclient.get(`${this.apiuserUrl}/${userId}`);
  }

  updatePerfil(userId: string, data: any): Observable<any> {
    return this.httpclient.put(`${this.apiuserUrl}/${userId}`, data);
  }

  logout() {
    sessionStorage.removeItem('userId');
    sessionStorage.clear();
    this.router.navigate(['/inicio']);
  }
}
