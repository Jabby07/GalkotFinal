import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApipublicacionesService {
  private apiUrl = 'https://galkotfinal.onrender.com/publicaciones'; 
  private postulacionesUrl = 'https://galkotfinal.onrender.com'; // URL para postulaciones

  constructor(private http: HttpClient) { }

  // Obtener todas las publicaciones
  getPublicaciones(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  // Obtener una publicación 
  getPublicacionById(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  // Crear una nueva publicación
  createPublicacion(publicacion: any): Observable<any> {
    return this.http.post(`${this.apiUrl}`, publicacion);
  }

  // Actualizar una publicación existente
  updatePublicacion(id: string, publicacion: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, publicacion);
  }

  // Eliminar una publicación
  eliminarPublicacion(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  // Obtener postulaciones por código de publicación
  getPostulacionesByCodigo(codigo: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.postulacionesUrl}?codigo=${codigo}`);
  }

  // Crear una nueva postulación
  postularTrabajo(postulacion: any): Observable<any> {
    return this.http.post(this.postulacionesUrl, postulacion);
  }
}
