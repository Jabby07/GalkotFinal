import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'index',
        loadChildren: () => import('../index/index.module').then( m => m.IndexPageModule)
      },
      {
        path: 'perfil',
        loadChildren: () => import('../perfil/perfil.module').then( m => m.PerfilPageModule)
      },
      {
        path: 'pagos',
        loadChildren: () => import('../pagos/pagos.module').then( m => m.PagosPageModule)
      },
      {
        path: 'lectorqr',
        loadChildren: () => import('../lectorqr/lectorqr.module').then( m => m.LectorqrPageModule)
      },
      {
        path: 'publicar',
        loadChildren: () => import('../publicar/publicar.module').then( m => m.PublicarPageModule)
      },
      {
        path: '',
        redirectTo: '../tabs/index',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/index',
    pathMatch: 'full'
  },
  
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
})
export class TabsPageRoutingModule {}
