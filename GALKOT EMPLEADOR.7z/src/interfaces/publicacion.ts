export interface Publicacion {
    id: string;
    nombrePublicacion: string;
    codigo: string;
    fecha: string;
    hora: string;
    monto: number;
    descripcion: string;

  }
  